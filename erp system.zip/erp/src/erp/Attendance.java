package erp;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.*;
import java.util.Date;
public class Attendance implements ActionListener{
JLabel jlab,jlab1,jlab2,jlab3;
JTextField jtf,jtf1,jtf2,jtf3;
JButton jb1;
JComboBox jcb1;
String url;
Connection con,savecon;
Statement st,savest;
  public Attendance() {
	  try {
  		String url="jdbc:oracle:thin:@localhost:1521:xe";
 			Class.forName("oracle.jdbc.driver.OracleDriver");
 			con=DriverManager.getConnection(url,"hr","abc");   			
 			st=con.createStatement();
 			st.executeQuery("create table  empatt_add(empid varchar(30),date_time varchar(30),status varchar(50))");
 			
			con.close();
	  }
	  catch (Exception ex) {
			System.out.print(ex);
		}
JFrame jfrm = new JFrame("Attendance");
jfrm.setLayout(new FlowLayout());
jfrm.setSize(520, 300);
Dimension screen = 	Toolkit.getDefaultToolkit().getScreenSize();
jfrm.setLocation((screen.width-500)/2,(screen.height-500)/2);
//jfrm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
JPanel jp = new JPanel(new GridLayout(4,1));
JPanel jp2 = new JPanel(new GridLayout(1,2));
jlab = new JLabel("EMP-ID");
jtf2 = new JTextField(15);

jp2.add(jlab);
jp2.add(jtf2);
jp.add(jp2);
//jlab.setText(new Date().toString());
JPanel jp3 = new JPanel(new GridLayout(1,2));
jlab2 = new JLabel("DATE & TIME");
jtf1 = new JTextField(new Date().toString());
jp3.add(jlab2);
jtf1.setEnabled(false);
jp3.add(jtf1);
jp.add(jp3); 


JPanel jp4 = new JPanel(new GridLayout(1,2));
jlab3 = new JLabel("STATUS  (P/A)");
jp4.add(jlab3);

jcb1 = new JComboBox();
jcb1.addItem("PRESENT");
jcb1.addItem("ABSENT");
jp4.add(jcb1);
jp.add(jp4);

jb1 = new JButton("SAVE");
jb1.addActionListener(this);
jp.add(jb1);
jfrm.add(jp);

jfrm.setVisible(true);
		
			System.out.println("anuj");
	
	  }
	 
  
	public void actionPerformed(ActionEvent ae) {
        Object source = ae.getSource();
		if(source==jb1)
		{
			addrecord(jtf2.getText().trim());
			
		} 

}
	
	
	void resetrecord()
	{

	jtf1.setText("");
	jtf2.setText("");
	//jcb1.setText("");
	}
	
	void addrecord(String empid)
	{
	try{
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		System.out.println("aman1");
	savecon=DriverManager.getConnection(url,"hr","abc");   
	savest =savecon.createStatement();



	System.out.println("aman2");
	if(!empid.equals(""))
	{String query = "SELECT * FROM empatt_add WHERE empid='" + empid +"'";
	ResultSet rs = savest.executeQuery(query);
	int foundrec = 0;
	while (rs.next())
	{
	JOptionPane.showMessageDialog(null,"already present","consider",JOptionPane.INFORMATION_MESSAGE);

	foundrec = 1;

	}
	if (foundrec == 0)
	{
		
		System.out.println("aman3");
	//String temp = "insert into empatt_add values('"+empid+"','"+jtf1.getText()+"','"+jtf3.getText()+"')";
	String temp = "insert into empatt_add values('"+empid+"','"+jtf1.getText()+"','"+jcb1.getSelectedItem()+"')";
	System.out.println("aman4");
	
	int result = savest.executeUpdate( temp );
	if ( result == 1 )
	{
	System.out.println("Recorded Added");
	resetrecord();
	JOptionPane.showMessageDialog(null, "Saved in DataBase","SUCCESS!!",JOptionPane.INFORMATION_MESSAGE);
								


	}
	else {
							
	JOptionPane.showMessageDialog(null, "Failed To Insert in DataBase","WARNING!!",JOptionPane.WARNING_MESSAGE);


	}
	}



	}

	else
	{
						
	JOptionPane.showMessageDialog(null, "Empty record", "failure", JOptionPane.INFORMATION_MESSAGE);

	}

	savecon.close();

	}

	catch(Exception ex)
	{
	JOptionPane.showMessageDialog(null,"Attendence added", "WARNING!!!",JOptionPane.INFORMATION_MESSAGE);
	}		




	}

}
