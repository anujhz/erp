package erp;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

public class Product_details   
{
JLabel jlb;

Product_details()  throws IOException
{
JFrame jfe = new JFrame("PRODUCT DETAILS--");
jfe.setLayout(new FlowLayout());
//jfe.setBackground(Color.PINK);
jfe.setSize(700,1000);
jfe.setResizable(false);
//jfe.setBackground(Color.PINK);
//jfe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
JPanel jp1= new JPanel(new GridLayout(5,1));
ImageIcon owner = new ImageIcon(Product_details.class.getResource("cico no 1.jpg"));// (login1.class.getResource("wp43.jpg"))
JButton jb1 = new JButton(owner);
jb1.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent ae){
try {
	//new Doc_file();
    File file = new File("cico no1.doc");
    
    //first check if Desktop is supported by Platform or not
    if(!Desktop.isDesktopSupported()){
        System.out.println("Desktop is not supported");
        return;
    }
     
    Desktop desktop = Desktop.getDesktop();
    if(file.exists()) desktop.open(file);
     



}
 catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}
});

jp1.add(jb1);
ImageIcon emp = new ImageIcon(Product_details.class.getResource("cico super.jpg"));
JButton jb2 = new JButton(emp);
jb2.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent ae){
	try {
		
	    File file1 = new File("cicosuper.doc");
	    
	    if(!Desktop.isDesktopSupported()){
	        System.out.println("Desktop is not supported");
	        return;
	    }
	     
	    Desktop desktop = Desktop.getDesktop();
	    if(file1.exists()) desktop.open(file1);
	}
	 catch (IOException e) {
		e.printStackTrace();
	}
}
});

jp1.add(jb2);

ImageIcon owner1 = new ImageIcon(Product_details.class.getResource("cico 3.jpg"));// (login1.class.getResource("wp43.jpg"))
JButton jb3 = new JButton(owner1);
jb3.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent ae){
//new Administration();

	try {
		
	    File file2 = new File("CICO 3.doc");
	    
	    if(!Desktop.isDesktopSupported()){
	        System.out.println("Desktop is not supported");
	        return;
	    }
	     
	    Desktop desktop = Desktop.getDesktop();
	    if(file2.exists()) desktop.open(file2);
	}
	 catch (IOException e) {
		e.printStackTrace();
	}
	
}
});

jp1.add(jb3);
ImageIcon emp1 = new ImageIcon(Product_details.class.getResource("tap.jpg"));
JButton jb4 = new JButton(emp1);
jb4.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent ae){
//new Employee();
	
	try {
		
	    File file3 = new File("tapecrete.doc");
	    
	    if(!Desktop.isDesktopSupported()){
	        System.out.println("Desktop is not supported");
	        return;
	    }
	     
	    Desktop desktop = Desktop.getDesktop();
	    if(file3.exists()) desktop.open(file3);
	}
	 catch (IOException e) {
		e.printStackTrace();
	}
	
}
});

jp1.add(jb4);

ImageIcon owner2 = new ImageIcon(Product_details.class.getResource("app.jpg"));// (login1.class.getResource("wp43.jpg"))
JButton jb5 = new JButton(owner2);
jb5.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent ae){
//new Administration();
	
	try {
		
	    File file4 = new File("sika solutions.doc");
	    
	    if(!Desktop.isDesktopSupported()){
	        System.out.println("Desktop is not supported");
	        return;
	    }
	     
	    Desktop desktop = Desktop.getDesktop();
	    if(file4.exists()) desktop.open(file4);
	}
	 catch (IOException e) {
		e.printStackTrace();
	}
	
}
});

jp1.add(jb5);

jfe.add(jp1);
//jlb = new JLabel("PLEASE CLICK ON ANY ONE IMAGE");
//jfe.add(jlb);

Dimension screen = 	Toolkit.getDefaultToolkit().getScreenSize();
jfe.setLocation((screen.width-550)/2,(screen.height-750)/2);

jfe.setVisible(true);
}
}

