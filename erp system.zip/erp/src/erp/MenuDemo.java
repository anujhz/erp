package erp;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

import javax.swing.*;
class MenuDemo implements ActionListener {
private static Object cLass;
JLabel jlab,background;;
JMenuBar jmb;
Container c;
JMenuItem jempd,jmiADD_EMPLOYEE,jmiUPDATE_DETAILS,jmiATTENDENCE,jmiExit,jmiADD_PRODUCT,jmiPRODUCT_DETAILS,jmiADD_SUPPLIER,jmiSUPPLIER_DETAILS,jmiEDIT_DETAIL,jmiADD_CUSTOMER,jmiCUSTOMER_DETAIL,jmiEDIT_CUSTOMER_DETAILS,jmiCUSTOMER1,jmiCHEMICAL_PURCHASE,jmiTUNKEY_BASIS,jmiSUPPLIER;
JFrame jfrm;
JMenu jmEMPLOYEE,jmPRODUCT,jmSUPPLIER,jmCUSTOMER,jmBILLING;
MenuDemo() {
jfrm = new JFrame("ADMINISTRATOR");
jfrm.setLayout(new FlowLayout());
jfrm.setSize(420, 400);
JPanel jp1 = new JPanel(new FlowLayout());

jlab = new JLabel();

jmb = new JMenuBar();

// Create the EMPLOYEE   menu.
jmEMPLOYEE= new JMenu("EMPLOYEE");
jempd = new JMenuItem("EMPLOYEE DETAILS");
jmiADD_EMPLOYEE = new JMenuItem("ADD EMPLOYEE");
jmiUPDATE_DETAILS = new JMenuItem("DELETE EMPLOYEE");
jmiATTENDENCE = new JMenuItem("ATTENDENCE DETAILS");
jmiExit = new JMenuItem("Exit");
jmEMPLOYEE.add(jempd);

jmEMPLOYEE.add(jmiADD_EMPLOYEE);

jmEMPLOYEE.add(jmiUPDATE_DETAILS);
jmEMPLOYEE.add(jmiATTENDENCE);
jmEMPLOYEE.addSeparator();
jmEMPLOYEE.add(jmiExit);
jmb.add(jmEMPLOYEE);

// Create the PRODUCT menu.
jmPRODUCT = new JMenu("PRODUCT");
//jmiADD_PRODUCT = new JMenuItem("ADD PRODUCT");
jmiPRODUCT_DETAILS = new JMenuItem("PRODUCT DETAILS");
//jmPRODUCT.add(jmiADD_PRODUCT);
jmPRODUCT.add(jmiPRODUCT_DETAILS);
jmb.add(jmPRODUCT);


//create the supplier menu
jmSUPPLIER =new JMenu("SUPPLIER");
jmiADD_SUPPLIER = new JMenuItem("ADD SUPPLIER");
jmiSUPPLIER_DETAILS = new JMenuItem("SUPPLIER DETAILS");
jmiEDIT_DETAIL = new JMenuItem("DELETE SUPPLIER");
jmSUPPLIER.add(jmiADD_SUPPLIER);
jmSUPPLIER.add(jmiSUPPLIER_DETAILS);
jmSUPPLIER.add(jmiEDIT_DETAIL);
jmb.add(jmSUPPLIER);

// Create the CUSTOMER menu.
jmCUSTOMER = new JMenu("CUSTOMER");
jmiADD_CUSTOMER = new JMenuItem("ADD CUSTOMER");
jmiCUSTOMER_DETAIL = new JMenuItem("CUSTOMER DETAIL");
jmiEDIT_CUSTOMER_DETAILS = new JMenuItem("DELETE CUSTOMER");
jmCUSTOMER.add(jmiADD_CUSTOMER);
jmCUSTOMER.add(jmiCUSTOMER_DETAIL);
jmCUSTOMER.add(jmiEDIT_CUSTOMER_DETAILS);
jmb.add(jmCUSTOMER);

// Create the BILLING menu.
jmBILLING = new JMenu("BILLING");
jmiCUSTOMER1 = new JMenuItem("CUSTOMER");
jmBILLING.add(jmiCUSTOMER1);
jmb.add(jmBILLING);

// Add action listeners for the menu items.
jempd.addActionListener(this);
jmiADD_EMPLOYEE.addActionListener(this);
jmiUPDATE_DETAILS.addActionListener(this);
jmiATTENDENCE.addActionListener(this);
jmiExit.addActionListener(this);
//jmiADD_PRODUCT.addActionListener(this);
jmiPRODUCT_DETAILS.addActionListener(this);
jmiADD_SUPPLIER.addActionListener(this);
jmiSUPPLIER_DETAILS.addActionListener(this);
jmiEDIT_DETAIL.addActionListener(this);
jmiADD_CUSTOMER.addActionListener(this);
jmiCUSTOMER_DETAIL.addActionListener(this);
jmiEDIT_CUSTOMER_DETAILS.addActionListener(this);
jmiCUSTOMER1.addActionListener(this);
// Add the label to the content pane.
jfrm.add(jlab);
// Add the menu bar to the frame.
jfrm.setJMenuBar(jmb);

Dimension screen = 	Toolkit.getDefaultToolkit().getScreenSize();
jfrm.setLocation((screen.width-500)/2,(screen.height-500)/2);

// Display the frame.
jfrm.setVisible(true);
}

private Container getContentPane() {
	// TODO Auto-generated method stub
	return null;
}

// Handle menu item action events.
public void actionPerformed(ActionEvent ae) {
// Get the action command from the menu selection.
String comStr = ae.getActionCommand();
// If user chooses Exit, then exit the program.
if(comStr.equals("Exit")){
	//System.exit(0);
	jfrm.dispose();
}

Object sour1 = ae.getSource();
if(sour1==jempd)
{
	new TableDemo();
}
Object sour2 = ae.getSource();
if(sour2==jmiADD_EMPLOYEE)
{
	new Emp_add();
}
Object sour3 = ae.getSource();
if(sour3==jmiUPDATE_DETAILS)
{
	new Emp_update();
	
}

Object sour4 = ae.getSource();
if(sour4==jmiPRODUCT_DETAILS)
{
    try {
		new Product_details();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}		
}
Object sour5 = ae.getSource();
if(sour5==jmiADD_CUSTOMER)
{
	new Customer_add();
	
}
Object sour6 = ae.getSource();
if(sour6==jmiEDIT_CUSTOMER_DETAILS)
{
	new Customer_update();
	
}
Object sour7 = ae.getSource();
if(sour7==jmiCUSTOMER_DETAIL)
{
	new Customer_details();
	
}
Object sour8 = ae.getSource();
if(sour8==jmiCUSTOMER1)
{
	new Cust_sales();
	
}
Object sour9 = ae.getSource();
if(sour9==jmiADD_SUPPLIER)
{
	new Supplier_add();
	
}
Object sour10 = ae.getSource();
if(sour10==jmiSUPPLIER_DETAILS)
{
	new Supplier_details();
	
}
Object sour11 = ae.getSource();
if(sour11==jmiEDIT_DETAIL)
{
	new Supplier_update();
	
}
Object sour12 = ae.getSource();
if(sour12==jmiATTENDENCE)
{
	new Attendance_details();
	
}
}
}
