package erp;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.LineBorder;

public class SplashScreen extends JWindow implements Runnable
{
	public void run()
	
	{
		
		//JLabel SplashScreenLabel = new JLabel(new ImageIcon(SplashScreen.class.getResource("FWS-FINAL-Logo1.jpg")));
		JLabel SplashScreenLabel = new JLabel(new ImageIcon(SplashScreen.class.getResource("Untitled.png")));
		//ImageIcon owner = new ImageIcon(Login1.class.getResource("wp43.jpg"));
		Dimension screen = 	Toolkit.getDefaultToolkit().getScreenSize();
		Color cl = new Color (255,200, 120);
		SplashScreenLabel.setBorder (new LineBorder (cl, 10));

		getContentPane().add(SplashScreenLabel,BorderLayout.CENTER);

		setSize(900,424);
		setLocation((screen.width-800)/2,(screen.height-500)/2);
		show();
	}
}