package erp;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Administration // implements ActionListener
{
JLabel jlb1,jlb2;
JTextField jtf1; 
Administration()
{
JFrame jfrm = new JFrame("ADMINISTRATION");
jfrm.setLayout(new FlowLayout());
jfrm.setSize(460, 190);
jfrm.setResizable(false);
//jfrm.setBackground(Color.PINK);
//jfrm.setBackground(Color.PINK);
//jfrm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//jfrm.setVisible(true);

jlb1 = new JLabel("User Name");
jtf1 = new JTextField(15);
jlb2 = new JLabel("Password");
JPasswordField jtf2 = new JPasswordField(15);

JPanel recpanel = new JPanel(new GridLayout(2,2));
recpanel.add(jlb1);
recpanel.add(jtf1);
recpanel.add(jlb2);
recpanel.add(jtf2);

JPanel jp1= new JPanel(new GridLayout(1,4));
JButton jbtn1 = new JButton("Login", new ImageIcon(Administration.class.getResource("select_Hover.png")));
//jbtn1.addActionListener(this);
jp1.add(jbtn1);

jbtn1.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent ae){
if( (jtf1.getText().equals("Bunty")) && (jtf2.getText().equals("abcd"))||(jtf1.getText().equals("Anuj")) && (jtf2.getText().equals("12345")))
{
	JOptionPane.showMessageDialog(null, "valid input");
new MenuDemo();
}
else
{
	JOptionPane.showMessageDialog(null, "invalid input");
}
}
});

JButton jbtn2 = new JButton("Exit", new ImageIcon(Administration.class.getResource("exit.png")));
//jbtn2.addActionListener(this);
jp1.add(jbtn2);

jbtn2.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent ae){
jfrm.dispose();
}
});




jfrm.add(recpanel);
jfrm.add(jp1);
Dimension screen = 	Toolkit.getDefaultToolkit().getScreenSize();
jfrm.setLocation((screen.width-500)/2,(screen.height-500)/2);



// Display the frame.
jfrm.setVisible(true);
}
}

	


