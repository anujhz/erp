package erp;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
public class Emp_update implements ActionListener
{
private static final String String = null;
JTextField jtf1,jtf2,jtf3,jtf4,jtf5,jtf6,jtf7,jtf8;
JLabel jlb1,jlb2,jlb3,jlb4,jlb5,jlb6,jlb7,jlb8;
String url;
Connection crcon,delcon,editcon,savecon;
Statement crst,delst,editst,savest;
JButton jb1,jb2,jb3;
    public Emp_update() {
    	
    	try {
    		url="jdbc:oracle:thin:@localhost:1521:xe";
   			Class.forName("oracle.jdbc.driver.OracleDriver");
   			crcon=DriverManager.getConnection(url,"hr","abc");   			
   			crst =crcon.createStatement();

    	
		JFrame jfe = new JFrame("DELETE EMPLOYEE-- ");
		jfe.setLayout(new FlowLayout());
		jfe.setSize(400, 400);
		Dimension screen = 	Toolkit.getDefaultToolkit().getScreenSize();
		jfe.setLocation((screen.width-500)/2,(screen.height-500)/2);
		jfe.setResizable(false);
		//jfe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel jp = new JPanel(new GridLayout(8,2));
		
				
		jlb1 = new JLabel("NAME");
	    jtf1 = new JTextField(15);
		jlb2 = new JLabel("EMP-ID");
		jtf2 = new JTextField(15);
		jlb3 = new JLabel("POST");
		
		/*JPanel jp2 = new JPanel(new GridLayout(1,1));
		JComboBox<String> jcb;
		String timepieces[] = {"Select","Supreviser", "Clerk", "Applicator","Helper","Foreman" };
		jcb = new JComboBox<String>(timepieces);
		jp2.add(jcb);*/
		
	
		jtf3 = new JTextField(15);
		jlb4 = new JLabel("FATHER'S NAME");
		jtf4 = new JTextField(15);
		jlb5 = new JLabel("PHONE NUMBER");
		jtf5 = new JTextField(15);
		jlb6 = new JLabel("DATE OF BIRTH");
		jtf6 = new JTextField(15);
		jlb7 = new JLabel("ADDRESS");
		jtf7 = new JTextField(15);
		jlb8 = new JLabel("E-MAIL");
		jtf8 = new JTextField(15);
		
	    jp.add(jlb1);
		jp.add(jtf1);
		jp.add(jlb2);
		jp.add(jtf2);
		jp.add(jlb3);
		jp.add(jtf3);
		jp.add(jlb4);
		jp.add(jtf4);
		jp.add(jlb5);
		jp.add(jtf5);
		jp.add(jlb6);
		jp.add(jtf6);
		jp.add(jlb7);
		jp.add(jtf7);
		jp.add(jlb8);
		jp.add(jtf8);
		
		jfe.add(jp);
		
		JPanel jp1 = new JPanel(new GridLayout(1,2));
        jb1 = new JButton("UPDATE");
        jb1.addActionListener(this);
        //jp1.add(jb1);
        jb3 = new JButton("DELETE");
        jb3.addActionListener(this);
        jp1.add(jb3);
        jb2 = new JButton("EXIT");
        
        jb2.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent ae){
        jfe.dispose();
        }
        });
        jp1.add(jb2);
        jfe.add(jp1);
        
	 jfe.setVisible(true);
	 
	// crst.executeQuery("CREATE TABLE  emp21_add  (ename varchar(30),empid number(20),post varchar(20),fname varchar(20),num number(15),dob varchar(20),address varchar(30),email varchar(20))");

	   crcon.close();
			}
			catch (Exception ex) {
				System.out.print("creating table "+ex);
			}


	}
    //jb1.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent ae) {
	         Object source = ae.getSource();
			if(source==jb1)
			{
				editrecord(jtf1.getText().trim(),jtf2.getText().trim());
			

			} 
			else if(source==jb3)
			{
				deleterecord(jtf2.getText().trim());
			

			} 

	}
    
	
	void resetrecord()
	{

	jtf1.setText("");
	jtf2.setText("");
	jtf3.setText("");
	jtf4.setText("");
	jtf5.setText("");
	jtf6.setText("");
	jtf7.setText("");
	jtf8.setText("");
	}

	
	
	
	
	
	void editrecord(String ename,String empid)
	{
	
         try{
            
editcon=DriverManager.getConnection(url,"hr","abc");   			
   			editst =editcon.createStatement();




            if(!empid.equals(""))
	{
             int id=Integer.parseInt(empid);
//String temp = "update EMP22_ADD set name = +'"+ cname  +"' where bill_no= '" + bill_no+"'" ;
String temp = "update EMP100_ADD set ename = +'"+ ename  +"' where empid= '" + id+"'";
             int result = editst.executeUpdate( temp );

if ( result == 1 )
{
						
JOptionPane.showMessageDialog(null, "record updated", "success", JOptionPane.INFORMATION_MESSAGE);
							
}

else

{
						
JOptionPane.showMessageDialog(null, "No such record upadtion", "no updation",JOptionPane.INFORMATION_MESSAGE); 
		
}
}
else
{

JOptionPane.showMessageDialog(null,"empty record for updation ","consider",JOptionPane.INFORMATION_MESSAGE);
}
editcon.close();
}
catch(Exception e)
{
JOptionPane.showMessageDialog(null,"enter 0 - 9","invalid format",JOptionPane.INFORMATION_MESSAGE);

}



}
	
	
	
	
	
	
	
	
	


void deleterecord(String empid)
{

try{


delcon=DriverManager.getConnection(url,"hr","abc");   			
delst =delcon.createStatement();



if(!empid.equals(""))
{
int id=Integer.parseInt(empid);
String temp = "DELETE from EMP100_ADD where empid= " + id ;
int result = delst.executeUpdate( temp );
if ( result == 1 )
{
							
JOptionPane.showMessageDialog(null, "record deleted", "status", JOptionPane.INFORMATION_MESSAGE);
							
}

else

{
							
JOptionPane.showMessageDialog(null, "No such record", "no deletion",JOptionPane.INFORMATION_MESSAGE); 
							

}
}
else
{
JOptionPane.showMessageDialog(null,"empty record for deletion ","consider",JOptionPane.INFORMATION_MESSAGE);

}
delcon.close();
}
catch(Exception e)
{
JOptionPane.showMessageDialog(null,e,"invalid format",JOptionPane.INFORMATION_MESSAGE);

}

}
}
