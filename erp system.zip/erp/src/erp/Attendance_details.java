package erp;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.*;

import java.awt.*;

class Attendance_details extends JFrame 
{
  Statement st;
  Connection con;
 JTable table;

  //Table

   DefaultTableModel tmodel;
   Container cpane;

  Attendance_details()
  {
		try{
String url="jdbc:oracle:thin:@localhost:1521:xe";
   			Class.forName("oracle.jdbc.driver.OracleDriver");
   			 con=DriverManager.getConnection(url,"hr","abc");   			
   		 st=con.createStatement();
}
catch(Exception e)
{
}


 setTitle("ATTENDANCE DETAILS--");
        setSize(600,600);
    	Dimension screen = 	Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((screen.width-600)/2,(screen.height-550)/2);
        setResizable(false);
cpane = getContentPane();

        //components

        tmodel = new DefaultTableModel();
        table = new JTable(tmodel);
        SetColHeader();
cpane.add(new JScrollPane(table));
table.setEnabled(false);
setVisible(true);
RetrieveData();


  }
private void SetColHeader()
  {
    tmodel.addColumn("Empid");
    tmodel.addColumn("Date & Time");
    tmodel.addColumn("Status");
    

  }
 private void RetrieveData ()
  {
    try
    {
      int row = tmodel.getRowCount();
System.out.println("no of rows "+row);     
 while(row > 0)
      {

        row--;
        tmodel.removeRow(row);
System.out.println("row deleted ");
      }

      //execute query
      ResultSet rs = st.executeQuery("Select * from empatt_add");

      //get metadata
      ResultSetMetaData md = rs.getMetaData();
      int colcount = md.getColumnCount();

      Object[] data = new Object[colcount];
      //extracting data


      while (rs.next())
      {
        for (int i=1; i<=colcount; i++)
        {
          data[i-1] = rs.getString(i);
System.out.println("value   "+data[i-1]);
        }
        tmodel.addRow(data);
      }
    }
    catch(Exception e) {System.out.println(e);  }
  }
}

