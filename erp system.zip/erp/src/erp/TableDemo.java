package erp;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.*;

import java.awt.*;

class TableDemo extends JFrame 
{
  Statement st;
  Connection con;
 JTable table;

  //Table

   DefaultTableModel tmodel;
   Container cpane;

  TableDemo()
  {
		try{
String url="jdbc:oracle:thin:@localhost:1521:xe";
   			Class.forName("oracle.jdbc.driver.OracleDriver");
   			 con=DriverManager.getConnection(url,"hr","abc");   			
   		 st=con.createStatement();
}
catch(Exception e)
{
}


 setTitle("EMPLOYEE DETAILS--");
        setSize(600,600);
    	Dimension screen = 	Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((screen.width-600)/2,(screen.height-550)/2);
        setResizable(false);
cpane = getContentPane();

        //components

        tmodel = new DefaultTableModel();
        table = new JTable(tmodel);
        SetColHeader();
cpane.add(new JScrollPane(table));
table.setEnabled(false);
setVisible(true);
RetrieveData();


  }
private void SetColHeader()
  {
    tmodel.addColumn("Name");
    tmodel.addColumn("Eid");
    tmodel.addColumn("Post");
    tmodel.addColumn("Fathers name");
    tmodel.addColumn("DOB");
    tmodel.addColumn("PNO");
    tmodel.addColumn("Address");
    tmodel.addColumn("Email");

  }
 private void RetrieveData ()
  {
    try
    {
      int row = tmodel.getRowCount();
System.out.println("no of rows "+row);     
 while(row > 0)
      {

        row--;
        tmodel.removeRow(row);
System.out.println("row deleted ");
      }

      //execute query
      ResultSet rs = st.executeQuery("Select * from emp100_add");

      //get metadata
      ResultSetMetaData md = rs.getMetaData();
      int colcount = md.getColumnCount();

      Object[] data = new Object[colcount];
      //extracting data


      while (rs.next())
      {
        for (int i=1; i<=colcount; i++)
        {
          data[i-1] = rs.getString(i);
System.out.println("value   "+data[i-1]);
        }
        tmodel.addRow(data);
      }
    }
    catch(Exception e) {System.out.println(e);  }
  }

}
