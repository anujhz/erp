package erp;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Login1  
{
JLabel jlb;

Login1()
{
JFrame jfe = new JFrame("NATIONAL BUILDING CORPERATION");
jfe.setLayout(new FlowLayout());
jfe.setSize(700,450);
jfe.setResizable(false);
jfe.getContentPane().setBackground(Color.LIGHT_GRAY);
jfe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
JPanel jp1= new JPanel(new GridLayout(1,2));
ImageIcon owner = new ImageIcon(Login1.class.getResource("wp43.jpg"));
JButton jb1 = new JButton(owner);
jb1.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent ae){
new Administration();
}
});

jp1.add(jb1);
ImageIcon emp = new ImageIcon(Login1.class.getResource("wp37.jpg"));
JButton jb2 = new JButton(emp);
jb2.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent ae){
new Employee();
}
});

jp1.add(jb2);
jfe.add(jp1);
jlb = new JLabel("PLEASE CLICK ON ANY ONE IMAGE");
jfe.add(jlb);

Dimension screen = 	Toolkit.getDefaultToolkit().getScreenSize();
jfe.setLocation((screen.width-500)/2,(screen.height-500)/2);

jfe.setVisible(true);
}
public static void main(String args[])
{
	SplashScreen FormSplash = new SplashScreen();
	  Thread ThFormSplash = new Thread(FormSplash);
	ThFormSplash.start();
	    while(!FormSplash.isShowing())
	    {
	      try
	      {
	        //Display the FormSplash for 5 seconds
	        Thread.sleep(5000);
	      }
	      catch(InterruptedException e)
	      {
	      }
	    }
	 FormSplash.dispose();	
	
	
	SwingUtilities.invokeLater(new Runnable(){
public void run(){	
Login1 frame = new Login1();
}
});
}
}//d:\project\mi.jar