package erp;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

import javax.swing.*;
public class MenuDemo1 implements ActionListener {
JLabel jlab;
JMenuItem jmiPRODUCT_DETAILS,jmAt1;
JMenu jmPRODUCT;
JMenu jmAt;
JMenuBar jmb;
JFrame jfrm;
public MenuDemo1() {
JFrame jfrm = new JFrame("EMPLOYEE");
jfrm.setLayout(new FlowLayout());
jfrm.setSize(420, 400);
//jfrm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
jlab = new JLabel();

jmb = new JMenuBar();
jmAt= new JMenu("ATTENDENCE");
jmAt1=new JMenuItem("ATTENDENCE ADD");
jmAt.add(jmAt1);
jmPRODUCT= new JMenu("PRODUCT");
jmiPRODUCT_DETAILS=new JMenuItem("PRODUCT DETAIL");
jmPRODUCT.add(jmiPRODUCT_DETAILS);
//JMenu jmD= new JMenu("DETAILS");
jmb.add(jmAt);
jmb.add(jmPRODUCT);
//jmb.add(jmD);
jmiPRODUCT_DETAILS.addActionListener(this);
jmAt1.addActionListener(this);

// Add the label to the content pane.
jfrm.add(jlab);
// Add the menu bar to the frame.
jfrm.setJMenuBar(jmb);

Dimension screen = 	Toolkit.getDefaultToolkit().getScreenSize();
jfrm.setLocation((screen.width-500)/2,(screen.height-500)/2);

// Display the frame.
jfrm.setVisible(true);
}
public void actionPerformed(ActionEvent ae) {
String comStr = ae.getActionCommand();
if(comStr.equals("Exit")) 
	{
	jfrm.dispose();
	}
Object sour4 = ae.getSource();
if(sour4==jmiPRODUCT_DETAILS)
{
    try {
		new Product_details();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}		
}
Object sour5 = ae.getSource();
if(sour5==jmAt1)
{
    new Attendance();		
}
}
}