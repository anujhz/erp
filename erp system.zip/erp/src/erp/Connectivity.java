package erp;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
class Connectivity  {
JLabel jlab;
String u1,p1;
String url;
Connection editcon;
Statement editst;
public Connectivity(String un,String pwd) {
	u1=un;
	p1=pwd;
	try {
		url="jdbc:oracle:thin:@localhost:1521:xe";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//crcon=DriverManager.getConnection(url,"hr","abc");   			
			//crst =crcon.createStatement();

			//System.out.println("start");
         
			editcon=DriverManager.getConnection(url,"hr","abc");   			
			   			editst =editcon.createStatement();



//System.out.println("111111"); 
			            if(!u1.equals("")&&!p1.equals(""))
				{
			           
			            	//System.out.println("22  "+un+"   "+pwd);
//String temp = "select * from employee where User_Name='"+u1 +"' and Password ='"+p1+"'";
  String temp = "select * from emp100_add where ename='"+u1 +"' and empid ='"+p1+"'";

//String temp = "select * from validation";
			
			ResultSet rs = editst.executeQuery(temp);
			int foundrec = 0;

			while (rs.next())
				  
			{
					
				
				foundrec=1;
			}
				if ( foundrec== 1)
				{
					 		//System.out.println("333");
										
JOptionPane.showMessageDialog(null, "valid user", "success", JOptionPane.INFORMATION_MESSAGE);
	new MenuDemo1();									
									}

				else

									{
									

JOptionPane.showMessageDialog(null, "not registered","sorry",JOptionPane.INFORMATION_MESSAGE); 
										

							}
			}
			
				
			

editcon.close();
}
	catch (Exception ex) {
		System.out.print("creating table "+ex);
	}



}
}      
