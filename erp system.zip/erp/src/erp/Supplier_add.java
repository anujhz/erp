package erp;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
public class Supplier_add implements ActionListener
{
JTextField jtf1,jtf2,jtf3,jtf4,jtf5,jtf6,jtf7,jtf8,jtf9;
JLabel jlb1,jlb2,jlb3,jlb4,jlb5,jlb6,jlb7,jlb8,jlb9;
String url;
Connection crcon,delcon,editcon,savecon;
Statement crst,delst,editst,savest;
JButton jb1,jb2;
    public Supplier_add() {
    	
    	try {
    		url="jdbc:oracle:thin:@localhost:1521:xe";
   			Class.forName("oracle.jdbc.driver.OracleDriver");
   			crcon=DriverManager.getConnection(url,"hr","abc");   			
   			crst =crcon.createStatement();
    	
		JFrame jfe = new JFrame("ADD SUPPLIER-- ");
		jfe.setLayout(new FlowLayout());
		jfe.setSize(400, 400);
		jfe.setResizable(false);
		Dimension screen = 	Toolkit.getDefaultToolkit().getScreenSize();
		jfe.setLocation((screen.width-500)/2,(screen.height-500)/2);
		//jfe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel jp = new JPanel(new GridLayout(7,2));
		
				
		jlb1 = new JLabel("NAME");
	    jtf1 = new JTextField(15);
		jlb2 = new JLabel("BILL NUMBER");
		jtf2 = new JTextField(15);
		jlb3 = new JLabel("PHONE NUMBER");
		
		
	
		jtf3 = new JTextField(15);
		jlb4 = new JLabel("ADDRESS");
		jtf4 = new JTextField(15);
		jlb5 = new JLabel("PAYMENT DONE");
		jtf5 = new JTextField(15);
		jlb6 = new JLabel("PAAYMENT REMAINNING");
		jtf6 = new JTextField(15);
		jlb7 = new JLabel("E-MAIL");
		jtf7 = new JTextField(15);
		
	    jp.add(jlb1);
		jp.add(jtf1);
		jp.add(jlb2);
		jp.add(jtf2);
		jp.add(jlb3);
		jp.add(jtf3);
		jp.add(jlb4);
		jp.add(jtf4);
		jp.add(jlb5);
		jp.add(jtf5);
		jp.add(jlb6);
		jp.add(jtf6);
		jp.add(jlb7);
		jp.add(jtf7);
		
		jfe.add(jp);
		
		JPanel jp1 = new JPanel(new GridLayout(1,2));
        jb1 = new JButton("ADD");
        jb1.addActionListener(this);
        jp1.add(jb1);
        jb2 = new JButton("EXIT");
        
        jb2.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent ae){
        jfe.dispose();
        }
        });
        jp1.add(jb2);
        jfe.add(jp1);
        
	 jfe.setVisible(true);
	 System.out.println("hello23");
	 crst.executeQuery("CREATE TABLE  emp23_add  (name varchar(30),bill_no varchar(20),num varchar(20),address varchar(20),payment_done varchar(15),payment_remaining varchar(20),email varchar(20))");
	 System.out.println("hellohfjh3");
	   crcon.close();
			}
			catch (Exception ex) {
				System.out.print("creating table "+ex);
			}


	}
    //jb1.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent ae) {
	         Object source = ae.getSource();
			if(source==jb1)
			{
				addrecord(jtf1.getText().trim(),jtf2.getText().trim());
				
			} 

	}
    
	
	void resetrecord()
	{

	jtf1.setText("");
	jtf2.setText("");
	jtf3.setText("");
	jtf4.setText("");
	jtf5.setText("");
	jtf6.setText("");
	jtf7.setText("");
	//jtf8.setText("");
	//jtf9.setText("");
	}

	void addrecord(String sname,String bill_no)
	{
	try{

	savecon=DriverManager.getConnection(url,"hr","abc");   			
	savest =savecon.createStatement();




	if(!sname.equals("") &&!bill_no.equals(""))
		//JOptionPane.showMessageDialog(null, "hello");
	{String query = "SELECT * FROM emp23_add WHERE bill_no='" + bill_no +"'";
	 System.out.println("hellojhggiigyyu");
	ResultSet rs = savest.executeQuery(query);
	int foundrec = 0;
	while (rs.next())
	{
	JOptionPane.showMessageDialog(null,"already present","consider",JOptionPane.INFORMATION_MESSAGE);

	foundrec = 1;

	}
	if (foundrec == 0)
	{
		
		JOptionPane.showMessageDialog(null, "welcome MR."+jtf1.getText());	
	String temp = "insert into emp23_add values('"+sname+"','"+bill_no+"','"+jtf3.getText()+"','"+jtf4.getText()+"','"+jtf5.getText()+"','"+jtf6.getText()+"','"+jtf7.getText()+"')";
				
	
	int result = savest.executeUpdate( temp );
	if ( result == 1 )
	{
	System.out.println("Recorded Added");
	resetrecord();
	JOptionPane.showMessageDialog(null, "Saved in DataBase","SUCCESS!!",JOptionPane.INFORMATION_MESSAGE);
								


	}
	else {
							
	JOptionPane.showMessageDialog(null, "Failed To Insert in DataBase","WARNING!!",JOptionPane.WARNING_MESSAGE);


	}
	}



	}

	else
	{
						
	JOptionPane.showMessageDialog(null, "Empty record", "failure", JOptionPane.INFORMATION_MESSAGE);

	}

	savecon.close();

	}

	catch(Exception ex)
	{
	JOptionPane.showMessageDialog(null,ex, "WARNING!!!",JOptionPane.INFORMATION_MESSAGE);
	}		




	}


    }


