package erp;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
public class Emp_details { 
	JFrame jfrm;
    Emp_details(){
        try {
    		String url="jdbc:oracle:thin:@localhost:1521:xe";
   			Class.forName("oracle.jdbc.driver.OracleDriver");
   			Connection con=DriverManager.getConnection(url,"hr","abc");   			
   			Statement st=con.createStatement();
   			ResultSet rs=st.executeQuery("select * from emp21_add");   			
   			while(rs.next()){
   			
   			 jfrm = new JFrame("swing controls");

   			//Give the frame an initial size.
   			jfrm.setSize(800, 600);
   			Dimension screen = 	Toolkit.getDefaultToolkit().getScreenSize();
   			jfrm.setLocation((screen.width-600)/2,(screen.height-600)/2);
   			
   			jfrm.setResizable(false);
   				String[] colHeads = { "Name", "id", "post", "fname", "dob", "phone no", "addresss", "email" };
   				//Initialize data.
   				Object[][] data = {
   						{ rs.getString(1) , rs.getInt(2) , rs.getString(3) , rs.getString(4) , rs.getInt(5) , rs.getString(6) , rs.getString(7) , rs.getString(8)
   						}
   				};
   		
   			//Create the table.
   				JTable table = new JTable(data,colHeads);
   				//Add the table to a scroll pane.
   				JScrollPane jsp = new JScrollPane(table);
   				//Add the scroll pane to the content pane.
   				jfrm.add(jsp);

   			
   				//Display the frame.
   				jfrm.setVisible(true);
   			}	
   			
   			con.close();
   			
		}
		catch (Exception ex) {
			System.out.print(ex);
		}
    }
}








//System.out.println(rs.getString(1) + "\t" + rs.getInt(2) + "\t" +rs.getString(3) + "\t" + rs.getString(4) + "\t" + rs.getInt(5) + "\t" + rs.getString(6) + "\t" + rs.getString(7) + "\t" + rs.getString(2));