package erp;


import java.sql.*;

import javax.swing.*;
import javax.swing.table.*;

import java.awt.*;
import java.awt.*;
import java.awt.event.*;


public class Cust_sales implements ActionListener{

	JLabel title,cname,caddress,cpno;
	JTextField cnametxt,caddresstxt,cpnotxt;
	JLabel billid,pname,qty,total,netcost;
	JTextField billidtxt,pnametxt,qtytxt,totaltxt;
	JButton load,enter;
	JFrame jf;
	JPanel p1,p1_p1,p1_p2,p1_p3,p1_p4,p2;
	   DefaultTableModel tmodel;
		JTable table;
		 Statement st;
		  Connection con;
		  int nc=0;
	

		  
		  
		  Cust_sales(){
	
	try{
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		  			Class.forName("oracle.jdbc.driver.OracleDriver");
		  			con=DriverManager.getConnection(url,"hr","abc");   			
		  		 st=con.createStatement();
		  		st.executeQuery("create table  product(pname varchar(30),price varchar(30))");
	 			st.executeQuery("insert into product values('cico1','5000')");
	 			st.executeQuery("insert into product values('cicosuper','7000')");
	 			st.executeQuery("insert into product values('cico3','3000')");
	 			st.executeQuery("insert into product values('tape','8000')");
	 			st.executeQuery("insert into product values('app','10000')");
	 			
	 			st.executeQuery("create table  bills(billid varchar(30),pname varchar(30),qty varchar(30),Total varchar(30))");
				con.close();
		}
		catch(Exception e)
		{
			System.out.print(e);
		}
	
	    jf=new JFrame();
		jf.setLayout(new GridLayout(2,1));
		jf.setSize(900, 600);
		//jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		p1=new JPanel();
		p1.setLayout(new GridLayout(4,1));
		
		
		p1_p1=new JPanel(new FlowLayout());
		title=new JLabel("Customer Billing");
		p1_p1.add(title);
		
		p1_p2=new JPanel(new GridLayout(3,2));
		cname=new JLabel("          Customer Name");
		caddress=new JLabel("          Address");
		cpno=new JLabel("          Mobile no.");
		cnametxt=new JTextField(15);
		caddresstxt=new JTextField(15);
	    cpnotxt=new JTextField(15);
		p1_p2.add(cname);
		p1_p2.add(cnametxt);
		p1_p2.add(caddress);
		p1_p2.add(caddresstxt);
		p1_p2.add(cpno);
		p1_p2.add(cpnotxt);
		
		p1_p3=new JPanel(new GridLayout(4,2));
		billid=new JLabel("          Bill Id");
		pname=new JLabel("          Product name");
		qty=new JLabel("          Quantity");
		total=new JLabel("          Total");
		
		billidtxt=new JTextField(15);
		pnametxt=new JTextField(15);
		qtytxt=new JTextField(15);
	    totaltxt=new JTextField(15);
		p1_p3.add(billid);
		p1_p3.add(billidtxt);
		p1_p3.add(pname);
		p1_p3.add(pnametxt);
		p1_p3.add(qty);
		p1_p3.add(qtytxt);
		p1_p3.add(total);
		p1_p3.add(totaltxt);
		
		 load=new JButton("Load");
		 load.addActionListener(this);
		 
		 enter=new JButton("enter");
		 enter.addActionListener(this);
		 
		 netcost=new JLabel("NetCost= RS.0");
		 
		 p1_p4=new JPanel(new FlowLayout());
		 p1_p4.add(load);
		 p1_p4.add(enter);
		 p1_p4.add(netcost);
		 
		 p1.add(p1_p1);
		 p1.add(p1_p2);
		 p1.add(p1_p3);
		 p1.add(p1_p4);
		 
		 p2=new JPanel(new FlowLayout());
		 tmodel = new DefaultTableModel();
		  table = new JTable(tmodel);
		     tmodel.addColumn("Bill ID");
		     tmodel.addColumn("Product NAME");
		     tmodel.addColumn("Quantity");
			 tmodel.addColumn("Total");
		   p2.add(new JScrollPane(table));
		   
		
		jf.add(p1);
		jf.add(p2);
		jf.setVisible(true);
	}

private void RetrieveData()
{
  try
  {
    int row = tmodel.getRowCount();
 
while(row > 0)
    {

      row--;
      tmodel.removeRow(row);

    }

    //execute query
    ResultSet rs = st.executeQuery("Select * from bills");

    //get metadata
    ResultSetMetaData md = rs.getMetaData();
    int colcount = md.getColumnCount();

    Object[] data = new Object[colcount];
    //extracting data


    while (rs.next())
    {
      for (int i=1; i<=colcount; i++)
      {
        data[i-1] = rs.getString(i);

      }
      tmodel.addRow(data); 
    }
   

  }
  
  catch(Exception e) {JOptionPane.showMessageDialog(null,e);  }
}

void loaddata()
{
	  
	   try {
		  
		   ResultSet rs=st.executeQuery("select * from emp22_add where name='"+cnametxt.getText()+"'");
		while(rs.next())
		{
			
				billidtxt.setText(rs.getString(2));
				caddresstxt.setText(rs.getString(4));
				cpnotxt.setText(rs.getString(3));

		}	
		   
		
	   }
	   
	 
	   catch(Exception e)
		{
		   JOptionPane.showMessageDialog(null,e);
		}
}


public void actionPerformed(ActionEvent ae) {
	 Object source= ae.getSource();
	 if(source==load)
	 {
		
		 loaddata();
	 }
	 if(source==enter)
	 {
		int a=0,b;
		 try {
				
			   ResultSet rs=st.executeQuery("select * from product where pname='"+pnametxt.getText()+"'");
			while(rs.next())
			{
				
					a=Integer.parseInt(rs.getString(2));  //here-this-gives-mrp-as-per-product-name
		
			}	
			
			
		   }
		   
		    catch(Exception e)
			{
			   JOptionPane.showMessageDialog(null,e);
			} 
		 b=a*Integer.parseInt(qtytxt.getText());
		totaltxt.setText(""+b);
		 
		 
	//only-insert-command-is-left-to-be-here-for-table-BILLS...........!!!!!!!
		try
		{
			st.executeUpdate("insert into bills values('"+billidtxt.getText()+"','"+pnametxt.getText()+"','"+qtytxt.getText()+"','"+totaltxt.getText()+"')");
		}
		catch(Exception e)
		{
			
		}
	nc=nc+Integer.parseInt(totaltxt.getText());	 
	netcost.setText("NetCost RS."+nc);	 
		 
	RetrieveData();
	 }
	 
	 }

}
